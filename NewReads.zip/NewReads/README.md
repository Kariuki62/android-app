Week 1
# ReadMore
Android app.

## Developer
Kelvin Kariuki

## Project Description
An Android app that enables users to search for their favorite books from a library and buy them.

## Technologies and Frameworks Used
Java 11

Android Studio

ButterKnife Dependencies

## Prerequisites
Android SDK v28

## Setup & Installation
1. Clone the repo
2. Open with Android Studio
3. Compile gradle build to build project
4. Setup emulator to view the project
5. Click run

## Contact Details
You can reach me at kariukiwan62@gmail.com

## LICENSE DETAILS
MIT Copyright (c) {2019} Kariuki Wanjohi https://github.com/Kariuki62/Readmore/blob/master/LICENSE



