package com.example.newreads.service;

import android.util.Log;

import com.example.newreads.models.Bookss;
import com.example.newreads.ui.Constants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class ReadService {
    private static final String TAG = ReadService.class.getSimpleName();

    public static void findTitle(String q, Callback callback) {
        String secret = "secret";
        OkHttpClient client = new OkHttpClient.Builder()
                .build();

        HttpUrl.Builder urlBuilder = HttpUrl.parse(Constants.GOODREADS_BASE_URL).newBuilder();
        urlBuilder.addQueryParameter(Constants.GOODREADS_KEY_PARAMETER,Constants.GOODREADS_TOKEN);
        urlBuilder.addQueryParameter(Constants.GOODREADS_BOOKS_QUERY_PARAMETER, q);
        String url = urlBuilder.build().toString();
        Log.e(TAG, url);

        Request request = new Request.Builder()
                .url(url)
                .build();

        Call call = client.newCall(request);
        call.enqueue(callback);
    }

    public static ArrayList<Bookss> processResults(Response response) {
        ArrayList<Bookss> books = new ArrayList<>();

        try {
            String xmlData = response.body().string();
            JSONObject readJSON = XML.toJSONObject(xmlData);
            JSONArray businessesJSON = readJSON.getJSONArray("books");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return books;
    }
}
